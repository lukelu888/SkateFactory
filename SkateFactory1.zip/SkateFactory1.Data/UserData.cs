﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkateFactory1.Data
{
    //establish communications back and forth with Sql Server
    public static class UserData
    {
    }
}
