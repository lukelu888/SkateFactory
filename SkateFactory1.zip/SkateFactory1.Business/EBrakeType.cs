﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkateFactory1.Business
{
    public enum EBrakeType
    {
        Undefined,
        Dynamic,
        Friction
    }
}
